# binancePump

Binance Pump Detector 

## What is this?

Creates a binance web socket and listen for trades. Aggragetes information, groups trade information via price.
prints out at the time interval most traded, price changed symbol.
This information could be detected an anomaly. An anomaly in binance could be leading to pump or dump.

Short or Long order can give on futures margin via software if you want


## How to run

```
$ git clone https://github.com/tugayakca/binancePump.git
$ python3 binancePumpV2.py

```

## Screen Shot

![Screenshot](binancePumpterminal.png)
